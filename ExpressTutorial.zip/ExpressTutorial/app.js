// const express = require('express');
// const app = express();

// app.get("/", (req,res) => {
//     res.send("Hello Everyone");
// })
// app.listen(5000);

//Importing sibling modules
const logger = require('./logger');
logger.log("Hello overloaded from logger to app");

console.log("Welcome Man!!");


//Using inbuilt modules
//const path = require('path');
// console.log(path.parse(__filename));
// console.log(path.extname('app.js'));
// console.log(path.parse('demo.txt'));

// const os = require('os');
// console.log(os.cpus());

// const Event = require('events');
// const emitter =new Event();
// emitter.on('logging an Event', (a,b) =>{
//     console.log("Load Event triggerd");
//     console.log(a,b)
// });

// emitter.emit('logging an Event',"argA", "argB");

// class Injection extends Event{
//     on()
// }

// const fs = require('fs');
// fs.writeFile('demo.txt', 'The content of the File', (err)  =>
// {
//     if(err){
//         console.log("Error has been occured");
//     } 
//     else{
//         console.log("File created Successfully");
//         fs.readFile('demo.txt', (err,file) =>{
//             if(err){
//                 console.log("Error occured while reading the file");
//                         }
//             else{
//                 //console.log(file);
//             }
//         })
//      }
// })

// 
//   readStream.on('data', (chunck) =>{
//       console.log(chunck);
//   })

//   const writeStream = fs.createWriteStream('demo1.txt');
//    writeStream.write(chunck);

  //piping
 //readStream.pipe(writeStream);

 //HTTP Module
//  const http = require('http');
//  const fs = require('fs');

//  const server  = http.createServer((req,res) =>{
//      if(req.url === '/'){
//         res.write("Welcome to Node Tutorial");
//         res.end();
//      }
//      else if(req.url === '/about'){
//             res.write("About Page of Node Tutorial");
//             res.end();
//      }
//      else if(req.url === "/home"){
        
//         const readStream = fs.createReadStream('index.html');
//        // res.writeHead(200, {'content-type' : 'text/html'});   ------why do we need this??
//          readStream.pipe(res);
//      }
//      else{
//          res.write("Page Not Found");
//          res.end();
//      }
     
//  }).listen('8000');

//Express
const express = require('express');
 const app1 = express();

 ///MiddleWare for JSON objects -- POST,PUT Services As we don't have DB now


//custom MiddleWare
app1.use((req,res,next) =>{
    console.log(req.url);
    next();
});

 const port = process.env.PORT || 5000;



 const routes = require('./moviesRoute')
 app1.use('/abc', routes);
 app1.listen(port, () =>{
     console.log(`Listening on PORT ${port}`);
 });



