function log(message){
    console.log(message);
}

var abc ="value;"

module.exports.log =log;
module.exports.abc =abc;