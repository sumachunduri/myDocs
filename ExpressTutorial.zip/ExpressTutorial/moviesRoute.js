const express = require('express');
const route = express.Router();

route.use(express.json());
const joi = require('@hapi/joi');

const movies = [
    {id:1 , name:'Star wars'},
    {id:2 , name:'Toy  Story'},
    {id:3 , name:'Transformers'}
]
const path = require('path');
route.get("/home",(req,res) =>{
    //Serving static files in EXPRESS
    res.sendFile(path.join(__dirname,'index.html'));
  
})

route.get("/api/movies",(req,res) =>{
    res.send(movies);
})
route.get('/api/movies/:id',(req,res) =>{
    let moviee = movies.find(c => c.id === parseInt(req.params.id));
     if(!moviee) res.send(`No movie found with id: ${req.params.id}`)
      res.send(moviee);
})
route.get("/person",(req,res) =>{
   res.send("This is a person Route");
})
route.get("/person/:name/:age",(req,res) =>{
   const NAME = req.params.name ;
   const AGE = req.params.age;
   res.send(`The person name is: ${NAME} and age is ${AGE}`);
})
route.post('/api/movies',  (req,res) =>{
   let postResult =  validate(req)
   if(postResult.error){
       res.status(400).send(postResult.error.details[0].message);
      
   }
   else{
       let movie = {
           id : movies.length + 1,
           name : req.body.name
       }
       movies.push(movie);
       res.send(movie);
   }
   
})
const validate = function(req) {
   const schema = joi.object({
       name : joi.string().min(3).required()
   })
   const result = schema.validate(req.body);
   console.log(result);
   return result;
}
route.put('/api/movies/:id', (req,res) => {
   let movie = movies.find(c => c.id === parseInt(req.params.id))
   if(!movie) res.send(`No movie found  with id: ${req.params.id}`);
// If movie found with ID
  let putResult = validate(req);
  if(putResult.error){
       
   res.status(400).send(putResult.error.details[0].message);
}
else 
 
  movie.name = req.body.name;
   res.send(movie);
 

})
route.delete('/api/movies/:id', (req,res) =>{
   let movie = movies.find(c => c.id === parseInt(req.params.id));
   if(!movie) res.send(`No movie found with id: ${req.params.id}`);
   
   const index = movies.indexOf(movie);
   movies.splice(index,1);
   res.send(movie);
})

module.exports = route;